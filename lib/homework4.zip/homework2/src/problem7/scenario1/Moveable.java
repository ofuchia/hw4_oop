package problem7.scenario1;

public interface Moveable {

    public void move();
}
