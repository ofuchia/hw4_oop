package problem6;

public interface Formatter {
	public String formatText(String s);
}
