package problem1;

public class OrnamentalLeaves extends FlowerBouquet{

    //constructor
    public OrnamentalLeaves(){
        description = "Ornamental Bouquet";
    }

//    public double getCost(){
//        return cost + whatever.0;
//    }
}
