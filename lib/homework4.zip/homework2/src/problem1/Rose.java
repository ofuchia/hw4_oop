package problem1;

public class Rose extends FlowerBouquet{

    //constructor to instantiate description and cost
    public Rose(){
        description = "Rose Bouquet";
    }


    public double getCost() {
        return 20.00;
    }

}
