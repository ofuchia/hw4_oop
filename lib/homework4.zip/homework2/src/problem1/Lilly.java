package problem1;

public class Lilly extends FlowerBouquet{

    //constructor
    public Lilly(){
        description = "Lilly Bouquet";
    }

//    @Override
//    public double getCost() {
//        return cost + whatever.0;
//    }
}
