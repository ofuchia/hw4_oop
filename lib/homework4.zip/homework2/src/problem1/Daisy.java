package problem1;

public class Daisy extends FlowerBouquet{

    //constructor
    //setting the description
    Daisy(){
        description = "Daisy Bouquet";
    }

    public double getCost() {
        return 15.0;
    }
}