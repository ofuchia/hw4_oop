package problem8;

public interface SortStrategy {
    public void sortFile(String filePath);
}
